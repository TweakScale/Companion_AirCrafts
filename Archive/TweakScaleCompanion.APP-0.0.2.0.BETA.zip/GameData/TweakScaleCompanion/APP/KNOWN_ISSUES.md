# TweakScale Companion :: Airplane Plus :: Known Issues

* Users of [All Tweak](https://forum.kerbalspaceprogram.com/index.php?/topic/182700-19x-all-tweak-07-23rdoctober2019/&tab=comments#comment-3553532) and [TMasterson5's TweakScale patches](https://forum.kerbalspaceprogram.com/index.php?/topic/181010-tmasterson5-mod-family/&tab=comments#comment-3513768) will probably have serious problems by installing this thing.
	+ Please backup everything first before installing, so up can rollback if needed.
