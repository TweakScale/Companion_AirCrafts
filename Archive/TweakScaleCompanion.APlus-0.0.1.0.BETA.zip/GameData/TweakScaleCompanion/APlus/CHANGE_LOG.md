# TweakScale Companion :: Airplane Plus :: Change Log

* 2020-0602: 0.0.1.0 Beta (Lisias) for KSP >= 1.2.2
	+ Initial public release
