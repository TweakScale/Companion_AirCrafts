# TweakScale Companion :: Neist Airliner Parts :: Change Log

* 2020-0907: 0.0.1.0 **BETA** (Lisias) for KSP >= 1.2.2
	+ First public release